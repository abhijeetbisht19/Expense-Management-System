//
//  DBRef.swift
//  login
//
//  Created by Deepanshu Upadhyaya on 30/05/23.
//

import Foundation
open class DBRef {

    func giveMeLuxury(captialLuxury : Int64) -> Int64 {
        let maxPercentage: UInt32 = 33 // aim for higher
        let randomPercentage = arc4random_uniform(maxPercentage + 1)
        let deductionValue = Int64(Double(captialLuxury) * Double(randomPercentage) / 100.0)
        let result = captialLuxury - deductionValue
        return result
    }
    
    func giveMeSavings(capitalSavings : Int64) -> Int64 {
        let maxPercentage : UInt32 = 53 // aim for lower
        let randomePercentage = arc4random_uniform(maxPercentage + 1)
        let deductionValue = Int64(Double(capitalSavings) * Double(randomePercentage) / 100.0)
        let result = capitalSavings + deductionValue
        return result
    }
    
    func giveMeNeeds(capitalNeeds: Int64) -> Int64 {
        let increaseDecrease = Int(arc4random_uniform(2))
        if increaseDecrease == 1 {
            let maxPercentage: UInt32 = 33 // aim for higher
            let randomPercentage = arc4random_uniform(maxPercentage + 1)
            let deductionValue = Int64(Double(capitalNeeds) * Double(randomPercentage) / 100.0)
            let result = capitalNeeds - deductionValue
            return result
        }
                
        let maxPercentage: UInt32 = 33 // aim for lower
        let randomPercentage = arc4random_uniform(maxPercentage + 1)
        let additionValue = Int64(Double(capitalNeeds) * Double(randomPercentage) / 100.0)
        let result = capitalNeeds + additionValue
        return result
            
    }
    
}
