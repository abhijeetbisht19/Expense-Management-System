//
//  MainOViewController.swift
//  login
//
//  Created by Deepanshu Upadhyaya on 28/05/23.
//

import UIKit
import FirebaseFirestore

class MainOViewController: UIViewController {
    var sSavings : String = ""
    var sLuxury : String = ""
    var sNeed : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //print(" viewdidload " + receivedData)
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var SalaryTextField: UITextField!
    
    @IBOutlet weak var NeedsTextField: UITextField!
    
    
    @IBOutlet weak var LuxuryTextField: UITextField!
    
    
    @IBOutlet weak var SavingTextField: UITextField!

    
    @IBAction func testbutton(_ sender: Any) {
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let destinationVC = segue.destination as? FinalViewController {
                destinationVC.rSavings = sSavings
                destinationVC.rLuxury = sLuxury
                destinationVC.rNeed = sNeed
            }
    }
    
    @IBAction func SubmitButton(_ sender: Any) {
        let salary = SalaryTextField.text ?? ""
        sNeed =  NeedsTextField.text ?? ""
        sLuxury = LuxuryTextField.text ?? ""
        sSavings = SavingTextField.text ?? ""
        

        
        
        self.performSegue(withIdentifier: "goToFinal", sender: nil)
        

        
    }
}
