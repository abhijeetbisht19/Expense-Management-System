//
//  LoginViewController.swift
//  login
//
//  Created by Deepanshu Upadhyaya on 04/03/23.
//

import UIKit
import Firebase
import FirebaseAuth

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordtextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    
    @IBAction func loginClicked(_ sender: Any) {
        guard let email = emailTextField.text else {return print("email not working")}
        guard let password = passwordtextField.text else {return print("pass not working")}
        Auth.auth().signIn(withEmail: email, password: password) { firebaseResult, error in
            if let e = error{
                print("Inside auth")
                print(e)
            }
            else{
                
               self.performSegue(withIdentifier: "goToNext", sender: nil)
                
            }
        }
    }
}
     

