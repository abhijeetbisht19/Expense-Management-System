//
//  createAccountViewController.swift
//  login
//
//  Created by Deepanshu Upadhyaya on 04/03/23.
//

import UIKit
import Firebase
import FirebaseFirestore

class createAccountViewController: UIViewController {
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    @IBOutlet weak var emailTextField: UITextField!
    
   
    @IBOutlet weak var nameTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func signupClicked(_ sender: UIButton) {
        print("clicked signup")
        guard let Name = nameTextField.text else {return }
        print(Name)
        
        guard let email = emailTextField.text else {return }
        print(email)
        guard let password = passwordTextField.text else{return }
        print(password)
        Auth.auth().createUser(withEmail: email, password: password) { firebaseResult, error in
            if let e = error{
                print(e)
            }
            else{
                //go to home screen
                self.performSegue(withIdentifier: "goToLogin", sender: self)
            }
        }
    }
}
