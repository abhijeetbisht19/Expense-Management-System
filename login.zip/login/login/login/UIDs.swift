//
//  UIDs.swift
//  login
//
//  Created by Deepanshu Upadhyaya on 29/05/23.
//

import Foundation
class DataModel {
    static let shared = DataModel()
    var passedData: String?
}

