//
//  FinalViewController.swift
//  login
//
//  Created by Deepanshu Upadhyaya on 28/05/23.
//

import UIKit
import FirebaseFirestore

class FinalViewController: UIViewController {
    var rSavings : String = ""
    var rLuxury : String = ""
    var rNeed : String = ""


    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let dbRef = DBRef()

        luxurylabel.text = String(dbRef.giveMeLuxury(captialLuxury : Int64(rLuxury)!))

        needlabel.text = String(dbRef.giveMeNeeds(capitalNeeds : Int64(rNeed)!))
        
        savingslabel.text = String(dbRef.giveMeSavings(capitalSavings : Int64(rSavings)!))
        
    }

    
    
    @IBOutlet weak var needlabel: UILabel!
    
    @IBOutlet weak var savingslabel: UILabel!
    
    @IBOutlet weak var luxurylabel: UILabel!
    


}
